import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Pedido } from '../pedido';
import { PedidosService } from '../pedidos.service';

@Component({
  imports: [RouterLink],
  selector: 'app-lista-pedidos',
  styleUrl: './lista-pedidos.css',
  templateUrl: './lista-pedidos.html',
})
export class ListaPedidos {
  pedidos: Pedido[] = [];

  constructor(private pedidosService: PedidosService) {
    this.atualizarPedidos();
  }

  atualizarPedidos(): void {
    this.pedidos = this.pedidosService.listar();
  }

  aceitar(id: number): void {
    this.pedidosService.aceitarPedido(id);
  }

  preparar(id: number): void {
    this.pedidosService.pedidoEmPreparo(id);
  }

  enviarParaEntrega(id: number): void {
    this.pedidosService.pedidoSaiuParaEntrega(id);
  }

  entregar(id: number): void {
    this.pedidosService.marcarEntregue(id);
  }

  cancelar(id: number): void {
    this.pedidosService.remover(id);
    this.atualizarPedidos();
  }
}
