export type PedidoStatus =
  | 'Pendente'
  | 'Aceito'
  | 'Em preparo'
  | 'Pronto'
  | 'Em rota'
  | 'Entregue'
  | 'Cancelado';

export interface Pedido {
  id: number;
  descricao: string;
  status: PedidoStatus;
}