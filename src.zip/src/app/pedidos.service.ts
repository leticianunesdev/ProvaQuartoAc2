import { Injectable } from '@angular/core';
import { Pedido, PedidoStatus } from './pedido';

@Injectable({
  providedIn: 'root',
})
export class PedidosService {
  private pedidos: Pedido[] = [];
  private proximoId = 1;

  listar(): Pedido[] {
    return this.pedidos;
  }

  adicionar(descricao: string): Pedido {
    const pedido: Pedido = {
      id: this.proximoId++,
      descricao: descricao.trim(),
      status: 'Pendente',
    };

    this.pedidos.push(pedido);
    return pedido;
  }

  remover(idPedido: number): void {
    this.pedidos = this.pedidos.filter((pedido) => pedido.id !== idPedido);
  }

  aceitarPedido(idPedido: number): void {
    this.alterarStatus(idPedido, 'Aceito');
  }

  pedidoEmPreparo(idPedido: number): void {
    this.alterarStatus(idPedido, 'Em preparo');
  }

  pedidoPronto(idPedido: number): void {
    this.alterarStatus(idPedido, 'Pronto');
  }

  pedidoSaiuParaEntrega(idPedido: number): void {
    this.alterarStatus(idPedido, 'Em rota');
  }

  marcarEntregue(idPedido: number): void {
    this.alterarStatus(idPedido, 'Entregue');
  }

  cancelarPedido(idPedido: number): void {
    this.alterarStatus(idPedido, 'Cancelado');
  }

  private alterarStatus(idPedido: number, novoStatus: PedidoStatus): void {
    const pedido = this.pedidos.find((item) => item.id === idPedido);

    if (pedido) {
      pedido.status = novoStatus;
    }
  }
}