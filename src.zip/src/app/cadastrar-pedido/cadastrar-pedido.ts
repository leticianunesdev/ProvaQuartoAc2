import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { PedidosService } from '../pedidos.service';

@Component({
  imports: [FormsModule, RouterLink],
  selector: 'app-cadastrar-pedido',
  styleUrl: './cadastrar-pedido.css',
  templateUrl: './cadastrar-pedido.html',
})
export class CadastrarPedido {
  descricaoPedido = '';
  mensagem = '';

  constructor(private pedidosService: PedidosService) {}

  cadastrar(): void {
    const descricao = this.descricaoPedido.trim();

    if (!descricao) {
      this.mensagem = 'Informe os itens do pedido do iFood';
      return;
    }

    this.pedidosService.adicionar(descricao);
    this.descricaoPedido = '';
    this.mensagem = 'pedido do iFood cadastrado com sucesso';
  }
}
